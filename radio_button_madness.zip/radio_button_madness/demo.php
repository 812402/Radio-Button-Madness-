<?php

include 'main.php';

radio_button_madness(3,'','lose.htm', 'win.htm');




?>