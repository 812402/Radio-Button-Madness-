<?php

function radio_button_madness($number, $action, $lose, $win)
{
	
	echo '<p>Welcome to Radio Button Madness!!!</p><br />';
	
	echo'<link rel="stylesheet" href="style.css" type="text/css" media="screen" charset="utf-8"/>';
	
	$start = 1;
	
	echo '<div id="buttons">';
	echo '<form method="post" action="'.$action.'">';
	
	while ($start <= $number) {
			
		echo'<input type="radio" name="random" value="'.$start.'">';
		
		$start++;
		
	}
	echo'<br />';
	echo'<br />';
	echo'<input type="submit" name="submit" value="Submit!"/>';
	echo'</div>';
	echo'</form>';
	
	if (isset($_POST['submit'])) {
		
		$random = rand(1, $number);
		
		if ($random ==$_POST['random']) {
			
			header('Location: '.$win );
			
		} else {
			
			header('Location: '.$lose );
			
		}
		
	}
	
	
}

?>